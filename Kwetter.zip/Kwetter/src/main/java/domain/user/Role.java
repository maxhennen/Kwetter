package domain.user;

public enum Role {
    User,
    Moderator,
    Administrator
}
