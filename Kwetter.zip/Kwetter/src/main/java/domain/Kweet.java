package domain;

import domain.user.User;

import java.time.LocalDateTime;

public class Kweet {

    private long id;
    private LocalDateTime DateTime;
    private String content;
    private Kweet kweet;
    private User user;

    public Kweet(long id, LocalDateTime dateTime, String content, Kweet kweet, User user) {
        this.id = id;
        DateTime = dateTime;
        this.content = content;
        this.kweet = kweet;
        this.user = user;
    }

    public long getId() {
        return id;
    }

    public LocalDateTime getDateTime() {
        return DateTime;
    }

    public String getContent() {
        return content;
    }

    public Kweet getKweet() {
        return kweet;
    }

    public User getUser() {
        return user;
    }

    @Override
    public String toString() {
        return "Kweet{" +
                "id=" + id +
                ", DateTime=" + DateTime +
                ", content='" + content + '\'' +
                '}';
    }
}
