package domain;

import domain.user.User;
import java.time.LocalDateTime;

public class Like {

    private long id;
    private LocalDateTime dateTime;
    private User user;
    private Kweet kweet;

    public Like(long id, LocalDateTime dateTime, User user, Kweet kweet) {
        this.id = id;
        this.dateTime = dateTime;
        this.user = user;
        this.kweet = kweet;
    }

    public long getId() {
        return id;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public User getUser() {
        return user;
    }

    public Kweet getKweet() {
        return kweet;
    }

    @Override
    public String toString() {
        return "Like{" +
                "id=" + id +
                ", dateTime=" + dateTime +
                ", user=" + user +
                ", kweet=" + kweet +
                '}';
    }
}
